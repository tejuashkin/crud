package com.cg.mypaymentapp.repo;

import java.util.List;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;

public interface WalletRepo {

	public boolean save(Customer customer);

	public Customer findOne(String mobileNo);
	
	public boolean Update(Wallet wallet);
	public List<Customer> getAllAccounts() ;

}
