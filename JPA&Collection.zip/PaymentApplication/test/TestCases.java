import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import java.math.BigDecimal;
public class TestCases {
	private Customer c;
	private Wallet w;
	private BigDecimal bd;
	@Before
	public void setUp() throws Exception {
		bd=new BigDecimal(1000000);
	
		
	}

	@Test
	public void IsCUstomerExists() {
		
		w=new Wallet(bd);
		c=new Customer("Harsha","7731090265",w);
		
		
		
		
	}

	@After
	public void tearDown() throws Exception {
	}

}
