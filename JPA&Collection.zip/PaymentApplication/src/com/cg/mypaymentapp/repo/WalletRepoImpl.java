package com.cg.mypaymentapp.repo;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.InvalidInputException;


public class WalletRepoImpl implements WalletRepo {
	private Map<String, Customer> details = new HashMap<>();
	
	
	public WalletRepoImpl (){
		BigDecimal amount1=new BigDecimal(3000);
		Wallet wd1=new Wallet(amount1);
		Customer c1=new Customer("Harsha","7731090265",wd1);
		details.put(c1.getMobileNo(), c1);
		
		BigDecimal amount2=new BigDecimal(2000);
		Wallet wd2=new Wallet(amount2);
		Customer c2=new Customer("Tejaswini","9493569170",wd2);
		details.put(c2.getMobileNo(), c2);
		
		BigDecimal amount3=new BigDecimal(5000);
		Wallet wd3=new Wallet(amount3);
		Customer c3=new Customer("Sai","9494403905",wd3);
		details.put(c3.getMobileNo(), c3);
		
	}
	
	
	
	@Override
	public boolean save(Customer customer) {
		if (getDetails().containsKey(customer.getMobileNo())) {
			System.out.println(" account already exits with this number");
			return false;
		} else {
			 details.put(customer.getMobileNo(),customer);
			System.out.println(" account created ");
			return true;
		}
	}

	@Override
	public Customer findOne(String mobileNo) {
		if (getDetails().containsKey(mobileNo)) {
			return getDetails().get(mobileNo);
		} else {
			try {
				throw new InvalidInputException("No such record exists with "+ mobileNo);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			return null;
		}
	}

	@Override
	public Map<String, Customer> getDetails() {
		return details;
	}

}
