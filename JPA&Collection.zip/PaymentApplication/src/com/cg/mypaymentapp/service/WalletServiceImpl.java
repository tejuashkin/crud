package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.Map;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.repo.WalletRepo;
import com.cg.mypaymentapp.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService {

	WalletRepo wp = new WalletRepoImpl();

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		Wallet w = new Wallet(amount);
		Customer c = new Customer(name, mobileno, w);
		wp.save(c);
		return c;
	}

	@Override
	public Customer showBalance(String mobileno) {
		if (wp.findOne(mobileno) != null) {
			System.out.println("Customer Balance:= " + wp.findOne(mobileno).getWallet().getBalance());
			return wp.getDetails().get(mobileno);
		} else {
			return null;
		}
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		try {
			if ((wp.findOne(sourceMobileNo) != null)) {
				if (amount.compareTo(wp.findOne(sourceMobileNo).getWallet().getBalance()) > 0) {
					throw new InsufficientBalanceException("Balance in your account is less to transfer");
				}
				if (wp.findOne(targetMobileNo) != null) {
					BigDecimal bd1 = wp.findOne(targetMobileNo).getWallet().getBalance().add(amount);
					BigDecimal bd2 = wp.findOne(sourceMobileNo).getWallet().getBalance().subtract(amount);
					wp.findOne(sourceMobileNo).getWallet().setBalance(bd2);
					wp.findOne(targetMobileNo).getWallet().setBalance(bd1);
					System.out.println("funds transferred to " + targetMobileNo + " from " + sourceMobileNo);
					return wp.findOne(targetMobileNo);
				}
			} 
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
		return null;

	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		if (wp.findOne(mobileNo) != null) {
			BigDecimal bd = wp.findOne(mobileNo).getWallet().getBalance().add(amount);
			wp.findOne(mobileNo).getWallet().setBalance(bd);
			return wp.findOne(mobileNo);
		}
		return null;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		try {
			if (amount.compareTo(wp.findOne(mobileNo).getWallet().getBalance()) > 0) {
				throw new InsufficientBalanceException("Balance in your account is less to withdraw");
			}
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
		if (wp.findOne(mobileNo) != null && (amount.compareTo(wp.findOne(mobileNo).getWallet().getBalance()) <= 0)) {
			BigDecimal bd1 = wp.findOne(mobileNo).getWallet().getBalance().subtract(amount);
			wp.findOne(mobileNo).getWallet().setBalance(bd1);
			System.out.println("aoumt withdrawn from " + mobileNo + " is: " + amount);
			return wp.findOne(mobileNo);
		}
		return null;
	}

	@Override
	public Map<String, Customer> getDetails() {
		// TODO Auto-generated method stub
		return wp.getDetails();
	}

}
