package com.cg.mypaymentapp.pl;

import java.math.BigDecimal;
import java.util.Scanner;

import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Application {
	static WalletService ws = new WalletServiceImpl();
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		// Map<String, Customer> details = ws.getDetails();
		while (true) {
			entryArguments();
			int option = sc.nextInt();
			switch (option) {
			case 1:
				enterDetailsForNewAccount();
				break;
			case 2:
				showBalance();
				break;
			case 3:
				fundTransfer();
				break;
			case 4:
				depositAmount();
				break;
			case 5:
				withdraw();
				break;
			case 6:
				System.exit(0);
			default:
				System.out.println("only 1 2 3 4 5 6 is present");
			}
			// details = ws.getDetails();
		}

	}

	public static void entryArguments() // Repeatedly asking options
	{
		System.out.println("enter 1 Create Customer\n" + "enter 2 Show balance\n" + "enter 3 funds transfer\n"
				+ "enter 4 deposit amount\n" + "enter 5 to withdraw amount\n" + "enter 6 to exit");

	}

	public static void enterDetailsForNewAccount() {
		System.out.println("Enter name mobileno amount");
		String name = sc.next();
		String mobileno = sc.next();
		BigDecimal amount = sc.nextBigDecimal();
		ws.createAccount(name, mobileno, amount);

	}

	public static void showBalance() {
		System.out.println("Enter mobileo");
		String mobileNo = sc.next();
		ws.showBalance(mobileNo);
	}

	public static void fundTransfer() {
		System.out.println("Enter srcMobile targetMobile amountToTransfer :");
		String sourceMobileNo = sc.next();
		String targetMobileNo = sc.next();
		BigDecimal amount = sc.nextBigDecimal();
		ws.fundTransfer(sourceMobileNo, targetMobileNo, amount);
	}

	public static void depositAmount() {
		System.out.println("Enter Mobile number and amount to be deposited: ");
		String mobileNo = sc.next();
		BigDecimal amount = sc.nextBigDecimal();
		ws.depositAmount(mobileNo, amount);
	}

	public static void withdraw() {
		System.out.println("Enter the mobilenumber and amount to withdraw");
		String mobileNo = sc.next();
		BigDecimal bd = sc.nextBigDecimal();
		ws.withdrawAmount(mobileNo, bd);
	}

}
